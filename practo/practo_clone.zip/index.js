var a = 54;
function msg() {
    if (a % 2 == 0) {
        document.write("even");
    }
    else {
        document.write("odd");
    }
}

function msg2() {
    switch (10 + 5) {
        case 5:
            document.write('false');
        case 4:
            document.write('false');
        case 9:
            document.write('true');
            break;
        default:
            document.write('bye bye')
    }
}




function grade() {

    var grade = 'C';
    var result;
    switch (grade) {
        case 'A':
            result = "A grade";
            break;

        case 'B':
            result = "B Grade";
            break;

        case 'C':
            result = "C Grade";
            break;

        case 'D':
            result = "D Grade";
            break;

        case 'E':
            result = "E Grade";
            break;

        case 'F':
            result = "F Grade";
            break;
        default:
            result = "no grade"
    }

    document.write(result)
}


function forloop(){
    var n=document.getElementById("number").value;
    for(i=1;i<=n;i++){
        document.write(i+ '<br/>')
    }
}

function whileloop(n){
    var i=1;
    while(i<=n){
        document.write(i + '<br/>');
        i++;
    }
}

function dowhile(n){
    var i=1;
    do{
        document.write(i+'<br/>');
    i++;
    }while(i<=n);
}

function object(){
    var add=new Function("num1","num2","return num1+num2");
    document.write(add(2,8));
}

function factorial(){
    var n=document.getElementById("number").value;

    var ans=0;
    var fact=1;
    for(i=1;i<=n;i++){
        fact=fact*i;
        i++;
    }
    ans=fact;
    document.write(fact);
}